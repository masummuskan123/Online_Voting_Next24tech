# E-Voting-Platform-With-Node.js-React.js-And-React-Native
This is a basic electronic voting system which helps citizens to cast votes for their preferred political party, to help reduce one source of corruption and bribery in your community/country as a whole, as i'd be using my country, Nigeria as a case study.
