import React from 'react'

function ErrorPage() {
    return (
        <div>
            <p id="fromErrorPage">404, Not Found</p>
            <p id="fromErrorPage">Page Does Not Exist</p>
        </div>
    )
}

export default ErrorPage
